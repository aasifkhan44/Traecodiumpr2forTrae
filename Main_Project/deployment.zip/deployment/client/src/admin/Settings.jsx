import React from 'react';

const Settings = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Game Settings</h1>
      <div className="card mb-6">
        <h2 className="text-xl font-bold mb-4">Configure Game</h2>
        <p className="mb-4">This is a placeholder for the admin game settings page.</p>
      </div>
    </div>
  );
};

export default Settings;
