import React from 'react';

const GameHistory = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Game History</h1>
      <div className="card mb-6">
        <h2 className="text-xl font-bold mb-4">Past Games</h2>
        <p className="mb-4">This is a placeholder for the admin game history page.</p>
      </div>
    </div>
  );
};

export default GameHistory;
