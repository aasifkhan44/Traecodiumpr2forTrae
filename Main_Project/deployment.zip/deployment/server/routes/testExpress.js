console.log('Testing express require...');
const express = require('express');
console.log('Express required successfully!');
