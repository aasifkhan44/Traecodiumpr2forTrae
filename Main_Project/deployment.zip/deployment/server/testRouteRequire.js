console.log('Testing commissionSettings_fixed require...');
const route = require('./routes/commissionSettings_fixed');
console.log('Route required successfully!');
